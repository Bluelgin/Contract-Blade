# 赤月 · 女仆模型来源与许可

原 Wine Fox / 酒狐角色与模型：TartaricAcid / 酒石酸菌及 Touhou Little Maid 模型包贡献者。
赤月大正酒狐 1.2.3 来源适配：Blade Tetra contributors。
本次改造：契约之刃（Contract Blade）。
上游项目：https://github.com/TartaricAcid/TouhouLittleMaid

当前版本采用粉白长发与同色狐尾、奶油白至赤色渐变衣裙，保留原袜子；移除背后月轮，并整理衣袖、领口、裙摆与饰件。适配车万女仆 1.5.3 的移动、生活、持物、战斗、枪械、法术及音乐动作，保留骨架上的人形与狐形切换。没有附带已撤回的专属佩刀外观或自定义攻击动作，也不包含 YSM 玩家动作资源。

模型、贴图及本次动画适配按 CC BY-NC-SA 4.0 提供。赤月改造版本的发布许可由本项目角色包提供者确认；原始来源和署名继续保留。转载需保留署名、许可及修改说明；仅限非商业用途，衍生版本采用相同许可。完整条款见 LICENSE-CC-BY-NC-SA-4.0.txt。
许可：https://creativecommons.org/licenses/by-nc-sa/4.0/

第三方美术不适用契约之刃代码的 MIT 许可。本项目不代表原作者背书，不附带商业授权。

2026-10-10 包封面更新：根据项目提供的三狐合照，用内置生图工具生成并调整方形插画，仅替换 pack.png 和女仆包标签图标。赤月、白狐、黑狐保持原角色设计与署名，继续保留上述 CC BY-NC-SA 4.0 通知。没有替换本体生成的 3D 微缩预览，也没有因本次封面更新改动角色几何、贴图或动作。

2026-10-10 approved crimson-wrap derivative: wine-red overlapping outer skirt, pale pleated inner skirt, cream sleeves with burgundy cuffs, red-gold head ribbon and waist cords. Original pink-white hair/tail, face, socks and shoes retained. Existing model ID, bone hierarchy and native maid animations preserved. CC BY-NC-SA 4.0 continues to apply.
