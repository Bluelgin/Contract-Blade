# Credits

Original Wine Fox character: TartaricAcid / 酒石酸菌, Touhou Little Maid.
Original GeckoLib assets: Touhou Little Maid model-pack contributors.
Source adaptation: Blade Tetra contributors, Akatsuki Wine Fox 1.2.3.
This derivative: White/Black Fox humanoids, three-tail animation, fitted and merged clothing, and Touhou Little Maid model-pack adaptation.

The original four-legged Wine Fox geometry and tail motion are preserved; its UV patch is relocated and recolored to silver-white or plum-black, without changing humanoid texels; the Akatsuki-specific moon mark is excluded. Humanoid geometry and the seven original custom clips are retained. Native maid, TAC, spell and music animations derive from Touhou Little Maid 1.5.3 with incompatible bone tracks removed or mapped to the retained Wine Fox rig.

Sources: https://github.com/TartaricAcid/TouhouLittleMaid ; local Akatsuki Wine Fox 1.2.3 source and model pack.
Assets are distributed under CC BY-NC-SA 4.0. Keep this attribution and license with redistributed derivatives. This pack is not endorsed by the original authors.

Runtime derivative for Contract Blade: crown geometry removed, player-facing descriptions and a hand-authored SVG pixel portrait icon. Full author attribution remains above despite the abbreviated UI author field. Character textures and animations are unchanged. The original attribution and CC BY-NC-SA 4.0 license above remain applicable.
